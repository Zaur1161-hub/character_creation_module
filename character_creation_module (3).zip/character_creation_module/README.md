# character_creation_module
Модуль создания персонажа для RPG игры
